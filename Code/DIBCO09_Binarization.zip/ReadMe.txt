%==================================================================
%  executable program for document image binarization
%  - Shijian Lu, Bolan, Su 15/March/2012
%==================================================================

* Related paper: 
	- S Lu, B Su, C L Tan. Document Image Binarization Using Background Estimation and Stroke Edges. International Journal on Document Analysis and Recognition, December 2010


* Introduction
	- The .p file is built on Matlab
	- This software can be used freely for research purposes.

* How to use:
	- type binarization.p <input image> <output image> in the matlab command windows
	- it supports all the image format that supproted by matlab.

* Contact:
	- subolan@comp.nus.edu.sg
	- http://www.comp.nus.edu.sg/~subolan/
