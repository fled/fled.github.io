%==================================================================
%  executable program for document image binarization
%  - Bolan, Su 14/September/2010
%==================================================================

* Related paper: 
	- Su B, S Lu and C L Tan, Binarization of historical document images using the local maximum and minimum, International Workshop on Document Analysis Systems, 9-11 June 2010, Boston, MA, USA.


* Introduction
	- The exe file is built on Windows platform; GCC compiler and OpenCV is
	used in the code. So the OpenCV libs(cv100.dll etc.) are needed to make sure
	the program run correctly under computers without OpenCV.
	- This software can be used freely for research purposes.

* How to use:
	- type Binarize.exe <input image> <output image> in the command life
	- it supports images in bmp,jpg format.

* Contact:
	- subolan@comp.nus.edu.sg
	- http://www.comp.nus.edu.sg/~subolan/
	